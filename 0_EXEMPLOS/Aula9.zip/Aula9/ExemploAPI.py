from flask import Flask
from flask import request
from Funcionario import db
from FuncionarioService import add_funcionario, get_funcionarios

app = Flask(__name__)
app.config['SQLALCHEMY_DATABASE_URI'] = 'postgresql://postgres:admin@localhost:5432/empresa'
db.init_app(app)

funcionario = []

# Executar flask --app ExemploAPI.py run 
@app.route("/funcionario/<id>/<nome>", methods=['POST'])
def createUrl(id: int, nome: str):
    novoFuncionario = {"id": id, "nome": nome}
    funcionario.append(novoFuncionario)
    return funcionario

# Rota para cadastro de funcionario
@app.route("/funcionario", methods=['POST'])
def create():
    add_funcionario(request.form.get("id"), request.form.get("nome"))

## Rota que recebe como parâmetro o nome e retorna os dados do funcionário que possui esse nome.
@app.route("/funcionario/nome/<nome>", methods=['GET'])
def getByName(nome: str):
    for i in range(0, len(funcionario)):
        if funcionario[i]["nome"] == nome:
            return funcionario[i]
    return {}

## Rota que recebe como parâmetro o id e retorna os dados do funcionário que possui esse id.
@app.route("/funcionario/<id>", methods=['GET'])
def getById(id: int):
    """for emp_id, emp_data in funcionario.items():
        if emp_id == id:
            return emp_data
            
    matches = list(filter(lambda emp: emp["id"] == id, funcionario))
    return matches[0] if matches else None
"""

    for i in range(0, len(funcionario)):
        if funcionario[i]["id"] == id:
            return funcionario[i]
    return {}

@app.route("/funcionario", methods=['GET'])
def getAll():
    return funcionario

# Rota para atualização de um funcionario
@app.route("/funcionario/<id>", methods=['PUT'])
def update(id: int):
    for i in range(0, len(funcionario)):
        if funcionario[i]["id"] == id:
            funcionario[i]["nome"] = request.form["nome"]

    return funcionario

# Rota para excluir um funcionario
@app.route("/funcionario/<id>", methods=['DELETE'])
def delete(id: int):
    for i in range(0, len(funcionario)):
        if funcionario[i]["id"] == id:
            del funcionario[i]
            return funcionario


#Exercício: UM endpoint busca de funcionários por parâmetros. (id ou nome) Ex: localhost:5000/funcionario?nome=Douglas
#  OU localhost:5000/funcionario?id=1


