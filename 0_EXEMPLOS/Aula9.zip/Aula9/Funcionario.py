from sqlalchemy.orm import declarative_base
from sqlalchemy import create_engine
from flask_sqlalchemy import SQLAlchemy
from sqlalchemy import Column, Integer, String

Base = declarative_base()
db = SQLAlchemy()

class Funcionario(Base):
    __tablename__ = "funcionario"

    # Columns
    id = Column(
        "id",
        Integer,
        primary_key=True,
    )
    nome = db.Column("nome", String(150), nullable=False)

engine = create_engine('postgresql://postgres:admin@localhost:5432/empresa')
Base.metadata.create_all(engine)