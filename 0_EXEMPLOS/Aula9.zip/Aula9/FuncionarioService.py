from Funcionario import Funcionario, db
import sqlalchemy

def add_funcionario(id: int, nome: str) -> Funcionario:
    """
    Insert a funcionario in the database.
    """
    funcionario = Funcionario(id=id, nome=nome)
    db.session.add(funcionario)

    db.session.commit()

    return funcionario

def get_funcionarios() -> sqlalchemy.orm.query.Query:
    """
    Get all funcionarios stored in the database.

    Returns:
        funcionarios (Funcionario) -- contains all funcionarios registered.
    """
    funcionarios = db.session.query(Funcionario).all()
    return funcionarios