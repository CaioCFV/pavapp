# This Python file uses the following encoding: utf-8
import os
from pathlib import Path
import sys
import json
import requests

from PySide2 import QtWidgets
from PySide2.QtCore import QFile
from PySide2.QtUiTools import QUiLoader


class Widget(QtWidgets.QWidget):
    def __init__(self):
        super(Widget, self).__init__()
        self.load_ui()
        self.buttonOk = self.findChild(QtWidgets.QPushButton, 'btn_cadastrar')
        self.buttonOk.clicked.connect(self.callAPIPost)
        self.btn_buscar = self.findChild(QtWidgets.QPushButton, 'btn_buscar')
        self.btn_buscar.clicked.connect(self.callAPI)
        self.btn_editar = self.findChild(QtWidgets.QPushButton, 'btn_editar')
        self.btn_editar.clicked.connect(self.callAPIPut)
        self.btn_excluir = self.findChild(QtWidgets.QPushButton, 'btn_excluir')
        self.btn_excluir.clicked.connect(self.callAPIDelete)

    def load_ui(self):
        loader = QUiLoader()
        path = os.fspath(Path(__file__).resolve().parent / "form.ui")
        ui_file = QFile(path)
        ui_file.open(QFile.ReadOnly)
        loader.load(ui_file, self)
        ui_file.close()

    def printButtonPressed(self):
        # This is executed when the button is pressed
        print('printButtonPressed')

    def callAPI(self):
        funcionarioId = self.findChild(QtWidgets.QLineEdit, 'lineId')
        print(funcionarioId.text())
        response = requests.get(f"http://localhost:5000/api/funcionarios/{funcionarioId.text()}")
        data = response.json()
        nome = self.findChild(QtWidgets.QLineEdit, 'lineNome')
        if nome:
            nome.setText(data["nome"])

    def callAPIPost(self):
        id = self.findChild(QtWidgets.QLineEdit, 'lineId')
        nome = self.findChild(QtWidgets.QLineEdit, 'lineNome')
        data = {
            "id": int(id.text()),
            "nome": nome.text(),
        }
        print(f"data {data}")
        response = requests.post("http://localhost:5000/api/funcionarios", data=data)
        id.setText("")
        nome.setText("")
        print(response.json())

    def callAPIPut(self):
        id = self.findChild(QtWidgets.QLineEdit, 'lineId')
        nome = self.findChild(QtWidgets.QLineEdit, 'lineNome')
        data = {
            "nome": nome.text(),
        }
        print(f"data {data}")
        response = requests.put(f"http://localhost:5000/api/funcionarios/{id.text()}", data=data)
        id.setText("")
        nome.setText("")
        print(response.json())

    def callAPIDelete(self):
        funcionarioId = self.findChild(QtWidgets.QLineEdit, 'lineId')
        requests.delete(f"http://localhost:5000/api/funcionarios/{funcionarioId.text()}")

if __name__ == "__main__":
    app = QtWidgets.QApplication([])
    widget = Widget()
    widget.show()
    sys.exit(app.exec_())
